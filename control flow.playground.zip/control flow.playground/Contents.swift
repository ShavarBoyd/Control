for index in 1...3 {
    print ("\(index) times 60 is \(index * 60)")
    

}

for index in 1...3 {
    print ("\(index) times 60 is \(index * 60)")
    

}

for index in 1...3 {
    print ("\(index) times 60 is \(index * 60)")
    

}

for index in 1...3 {
    print ("\(index) times 60 is \(index * 60)")
    

}

var timer = 60

if timer <= 60 {
    print("Time is up")
}

